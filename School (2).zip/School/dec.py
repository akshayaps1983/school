def dec_fun(fun):
    def wrapper(a,b):
        if a>b:
            return fun(a,b)
        else:
            return fun(a,b)
    return wrapper

@dec_fun
def diff(a,b):
    return a-b
@dec_fun
def div(a,b):
    return a/b
print(diff(100,20))
print(div(100,20))

def signin_required(fun):
    def wrapper(self,req,*args,**kwargs):
        if req.user.is_autheticated:
            return fun(self,req,*args,*kwargs)
        else :
            return redirect("log")
        return wrapper


