from django.db import models

# Create your models here.
class StudentModel(models.Model):
    firstname=models.CharField(max_length=100)
    lastname=models.CharField(max_length=100)
    address=models.CharField(max_length=100)
    age=models.IntegerField()
    email=models.EmailField(null=True)
    phone=models.IntegerField()
    image=models.ImageField(upload_to="student_images",null=True)

