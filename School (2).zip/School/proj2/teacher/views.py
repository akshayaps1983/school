from django.shortcuts import render,redirect
from django.views.generic import View
from django.http import HttpResponse
from .forms import *
from django.contrib import messages
from .models import StudentModel
from django.utils.decorators import method_decorator

# Create your views here.
def signin_required(fun):
    def wrapper(req,*args,**kwargs):
        if req.user.is_authenticated:
            return fun(req,*args,*kwargs)
        else :
            return redirect("log")
    return wrapper
@method_decorator(signin_required,name="dispatch")
class AddMarkView(View):
   def get (self,req,*args, **Kwargs):
    f=AddMarkForm()
    return render(req,"addmark.html",{"forms":f})
   def post(self,req,*args,**kwargs):
        form_data=AddMarkForm(data=req.POST)
        if form_data.is_valid():
            sub1=form_data.cleaned_data.get("n1")
            sub2=form_data.cleaned_data.get("n2")
            sub3=form_data.cleaned_data.get("n3")
            sub4=form_data.cleaned_data.get("n4")
            sub5=form_data.cleaned_data.get("n5")
            res=int(sub1)+int(sub2)+int(sub3)+int(sub4)
            return render (req,"addmark.html",{"abc":res})
        else:
            return HttpResponse("invalid")
#class AddStudentVew(View):
  #  def get (self,req,*args, **kwargs):
   #     f=AddStudentForm()
   #     return render(req,"addstudent.html",{"forms":f})
   # def post(self,req,*args,**kwargs):
        #form_data=AddStudentForm(data=req.POST)
        #if form_data.is_valid():
          #  fn=(form_data.cleaned_data.get("first_name"))
            #ln=(form_data.cleaned_data.get("last_name"))
           # age=(form_data.cleaned_data.get("age"))
            #email=(form_data.cleaned_data.get("email"))
            #phone=(form_data.cleaned_data.get("phone"))
            #address=(form_data.cleaned_data.get("address"))
            #StudentModel.objects.create(firstname=fn,lastname=ln,age=age,phone=phone,email=email,address=address)
           #  return redirect("h")
       # else:
              #  messages.error(req,"student adding failed!!!!!!!!")
                #return render(req,"addstudent.html",{"forms":form_data})
@method_decorator(signin_required,name="dispatch")

class AddStudentMForm(View):
    def get(self,request,*arg,**kwargs):
        f=StudentMForm()
        return render(request,"addstudent.html",{"form":f})
    def post(self,request,*arg,**kwargs):
        form_data=StudentMForm(data=request.POST,files=request.FILES)
        if form_data.is_valid():
           form_data.save()
           messages.success(request,"Student adding failed!!!")
           return redirect("h")
        else:
            messages.error(request,"Student adding failed!!!")
            return  render(request,"addstudent.html",{"form":form_data})



@method_decorator(signin_required,name="dispatch")
class ViewStudent(View):
    def get(self,request,*args, **kwargs):
           res=StudentModel.objects.all()
           return render(request,"viewsstud.html",{"data":res})
       
@method_decorator(signin_required,name="dispatch")
class StudDeleteView(View):
    def get(self,req,*args,**kwargs):
        sid=kwargs.get("ssid")
        stu=StudentModel.objects.get(id=sid)
        stu.delete()
        return redirect("viw")
# class StudEditView(View):
#     def get(self,req,*args,**kwargs):
#         id=kwargs.get("sid")
#         stu=StudentModel.objects.get(id=id)
#         f=AddStudentForm(initial={"first_name":stu.firstname,"last_name":stu.lastname,"age":stu.age,"address":stu.address,"phone":stu.phone,"email":stu.email})
#         return render(req,"editstudent.html",{"form":f})
#     def post(self,req,*args,**kwargs):
#         form_data=AddStudentForm(data=req.POST)
#         if form_data.is_valid():
#             fn=(form_data.cleaned_data.get("first_name"))
#             ln=(form_data.cleaned_data.get("last_name"))
#             age=(form_data.cleaned_data.get("age"))
#             email=(form_data.cleaned_data.get("email"))
#             phone=(form_data.cleaned_data.get("phone"))
#             address=(form_data.cleaned_data.get("address"))
#             id=kwargs.get("sid")
#             stu=StudentModel.objects.get(id=id)
#             stu.firstname=fn
#             stu.lastname=ln
#             stu.age=age
#             stu.phone=phone
#             stu.address=address
#             stu.email=email
#             stu.save()
#             messages.success(req,"Student-Details updated Successfully")
#             return redirect("viw")
#         else:
#             messages.error(req,"Updation Failed...")
#             return render(req,"editstudent.html",{"form":form_data})
@method_decorator(signin_required,name="dispatch")
class StudentEditView (View):
    def get(self,req,*args,**kwargs):
        id=kwargs.get("sid")
        stu=StudentModel.objects.get(id=id)
        f=StudentMForm(instance=stu)
        return render(req,"editstudent.html",{"form":f})
    def post(self,req,*args,**kwargs):
        id=kwargs.get("sid")
        stu=StudentModel.objects.get(id=id)
        form_data=StudentMForm(data=req.POST,instance=stu,files=req.FILES)
        if form_data.is_valid():
           form_data.save()
           messages.success(req,"Student-Details Updated Successfully!!")
           return redirect("viw")
        else:
            messages.error(req,"Updation Failed...") 
            return render(req,"editstudent.html",{"form":form_data})

    


    

