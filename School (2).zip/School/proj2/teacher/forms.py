from django import forms
from.models import StudentModel
class AddMarkForm(forms.Form):
    n1=forms.IntegerField(label="enter sub1 mark",widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enter mark 1"}))
    n2=forms.IntegerField(label="enter sub2 mark",widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enter mark 2"}))
    n3=forms.IntegerField(label="enter sub3 mark",widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enter mark 3"}))
    n4=forms.IntegerField(label="enter sub4 mark",widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enter mark 4"}))
    n5=forms.IntegerField(label="enter sub5 mark",widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enter mark 5"}))
    def clean(self):
        cleaned_data=super().clean()
        n1=cleaned_data.get("n1")
        n2=cleaned_data.get("n2")
        n3=cleaned_data.get("n3")
        n4=cleaned_data.get("n4")
        if n1<0:
            msg="mark less than zero.Invalid input"
            self.add_error("n1",msg)
        if n2<0:
            msg="mark less than zero.invalid input"
            self.add_error("n1",msg)
        if n3<0:
            msg="mark less than zero.invalid input"
            self.add_error("n1",msg)
        if n4<0:
            msg="mark less than zero.invalid input"
            self.add_error("n1",msg)

class AddStudentForm(forms.Form):
    first_name=forms.CharField(max_length=100,widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enter your first name"}))   
    last_name=forms.CharField(max_length=100,widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enter your last name"}))     
    age=forms.IntegerField(widget=forms.NumberInput(attrs={"class":"form-control","placeholder":"enter your first age"}))
    address=forms.CharField(max_length=100,widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enter your address"}))    
    email=forms.EmailField(widget=forms.EmailInput(attrs={"class":"form-control","placeholder":"enter your email"}))
    phone=forms.IntegerField(widget=forms.NumberInput(attrs={"class":"form-control","placeholder":"enter your first phone number"}))
    
    def clean(self):
        cleaned_data=super().clean()
        fn=cleaned_data.get("first_name")
        ln=cleaned_data.get("last_name")
        age=cleaned_data.get("age")
        email=cleaned_data.get("email")
        phone=str(cleaned_data.get("phone"))
        address=cleaned_data.get("address")

        if fn==ln:
            self.add_error("last_name","last_name and last_name are same")
        if age<1:
            self.add_error("age","age is invalid")
        if len(phone)!=10:
            self.add_error("phone","digit are not 10")
class StudentMForm(forms.ModelForm):
        class Meta:
            model=StudentModel
            fields="__all__"
            widgets={
                "firstname":forms.TextInput(attrs={"class":"form-control","placeholder":"First Name"}),
                "lastname":forms.TextInput(attrs={"class":"form-control","placeholder":"Last Name"}),
                "age":forms.NumberInput(attrs={"class":"form-control","placeholder":"Age"}),
                "address":forms.Textarea(attrs={"class":"form-control","placeholder":"Address"}),  
                "phone":forms.NumberInput(attrs={"class":"form-control","placeholder":"Phone"}),
                "email":forms.EmailInput(attrs={"class":"form-control","placeholder":"Email"}),
                "image":forms.FileInput(attrs={"class":"form-control","placeholder":"Image"}),
            }
        def clean(self):
                cleaned_data=super().clean()
                fn=cleaned_data.get("firstname")
                ln=cleaned_data.get("lastname")
                age=cleaned_data.get("age")
                email=cleaned_data.get("email")
                phone=str(cleaned_data.get("phone"))
                address=cleaned_data.get("address")

                if fn==ln:
                        self.add_error("lastname","firstname and lastname are same")
                if age<1:
                        self.add_error("age","Age is invalid")
                if len(phone)!=10:
                        self.add_error("phone","Digit are not 10")


