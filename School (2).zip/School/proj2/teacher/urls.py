from django.urls import path
from.views import *
urlpatterns=[
    path('add/',AddMarkView.as_view(),name="adm"),
    path('sub/',AddStudentMForm.as_view(),name="addstudent"),
    path('view/',ViewStudent.as_view(),name="viw"),
    path('delstudent/<int:ssid>',StudDeleteView.as_view(),name="delstu"),
    path('edit/<int:sid>',StudentEditView.as_view(),name="edit"),
]