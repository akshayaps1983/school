from django.urls import path
from.views import RegView,HomeView,LogoutView
urlpatterns=[
    
    path('registration/',RegView.as_view(),name="regisration"),
    path('',HomeView.as_view(),name="h"),
    path('logout',LogoutView.as_view(),name="lgout"),
    
    
]