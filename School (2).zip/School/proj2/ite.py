class Myclass:
    namee="akku"
    @property
    def fun(self):
        return "hi"
ob=Myclass()
print(ob.namee)
print(ob.fun)